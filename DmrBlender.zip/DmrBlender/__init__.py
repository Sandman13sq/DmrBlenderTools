#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#  All rights reserved.
#  ***** GPL LICENSE BLOCK *****

# <pep8 compliant>

bl_info = {
    'name': 'Dmr Blender Tools',
    'author': 'Dreamer13sq',
    }

# can use importlib.reload here instead 
import bpy
#from .operators import *
#from .panels import *
from . import utilities, dmr_hotmenu, dmr_misc_op, dmr_pose_op, dmr_sculpt_op, dmr_shapekey_op, dmr_vcolor_op, dmr_vertex_op, dmr_vgroup_op, dmr_pose_panel, dmr_shapekey_panel, dmr_vcolor_panel, dmr_vgroup_panel;

def register():
    print('> Register()')
    dmr_hotmenu.register();

if __name__ == "__main__":
    print('> Main')
    register()
